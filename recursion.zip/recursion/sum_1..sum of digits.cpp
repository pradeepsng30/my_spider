#include<iostream>
#include<conio.h>

using namespace std;

int sum(long int n)//without extending argument
{
	
	if(n>0)
		{
		
		return n%10 + sum(n/10);//return sum of last digit and sum of rest of the digits by calling sum again after eliminating last digit
		}
	else return 0;// recursion continues till n reaches to zero;
}


int sum(long int n,int digit_sum)//by extending arguements
{                   //digit_sum stores the sum of digits which is initialised as 0 while calling
	if(n>0)  //till n>0
		{    digit_sum += n%10; 
				//value of digit_sum is incremented by last digit of n
				
			 return sum(n/10,digit_sum);
			/*sum() is called again by eliminating last digit of n and storing it it in digit_sum as sum */
	
		}
	else
		return digit_sum; // if n becomes zero then digit sum contains sum of all digits
}

main()
{
int n;
cout<<"Sum of Digits \n\nEnter a no. to find the sum of its digits :";
cin>>n;
cout<<"\n\nSum of its digits is(without extending arguement)"<<sum(n);
cout<<"\n\nSum of its digits is(by extending arguement)"<<sum(n,0);
getch();

}	
