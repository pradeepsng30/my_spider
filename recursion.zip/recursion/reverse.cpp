#include<iostream>
#include<conio.h>
#include<string.h>
#include<stdio.h>
using namespace std;

char sentence[1000];

void reverse(char a[])// a is string
{     char temp;
   static int i=0 ; // counts the no. of times the function is called
   i++;
   
   
   if(strlen(a)>strlen(sentence)/2) // continues till the size of sub string is greater than half the size of main string
   	{ temp =a[0];
   	  a[0]=a[strlen(a)-i];    //swapping the i-th element of string with i-th element from back
	  a[strlen(a)-i]=temp;
	  
	  reverse(a+1); // function calls itself by incrementing the pointer..i.e. by passing a sub string after eliminating the first character  	
   	}                                                      
   	
   
}


main()
{
	cout<<"string reverse\n\nEnter a sentence: ";
	gets(sentence);
	
	reverse(sentence);
	
	cout<<"reversed sentence is : \n";
	puts(sentence);
	
	getch();
	
}
