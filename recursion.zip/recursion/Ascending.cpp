#include<iostream>
#include<conio.h>

using namespace std;

void ascending_natural(int n)
{
   static int i=0;           //static variable i is initialised
   i++;                      // i is incremented each time the function is called
   if(i<=n){                 //
   			cout<<i<<" ";
			ascending_natural(n);  // function calls itself till i<=n
			}
	else return;		 
}

main()
{ 
	int n;
	
	cout<<"Ascendng order... by recursion\n\nupto wich no. you want output :";
	cin>>n;
	
	ascending_natural(n);
	getch();	
}
