#include<iostream>
#include<conio.h>

using namespace std;

void descending_natural(int n)
{
   
   if(n>0){                 //end point n=1
   			cout<<n<<" ";
			descending_natural(n-1);  // function calls itself till n>0, with a reduced value of argument n
			}
	else return;		 
}

main()
{ 
	int n;
	
	cout<<"Descendng order... by recursion\n\nfrom which no. you want output :";
	cin>>n;
	
	descending_natural(n);
	getch();	
}
