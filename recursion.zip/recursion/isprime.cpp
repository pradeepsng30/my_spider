#include<iostream>
#include<conio.h>

using namespace std;

bool isprime(int n,int i)//n=number which is to be checked and i is a divisor
{
		 if(i>1)          //if i>1
		  { if(n%i==0)    //if n is divisible by i
		  		return false;  // then n is not a prime
		  	else return isprime(n,i-1);	//  if n is not divisible by i then check if it is divisible by i-1 ,by calling isprime again by reducing calue of divisor
									   // this continues till i is reduced to 2
									   // i starts with a value n/2 i.e. GIF(n/2)
		  }
		 else return true;// if n is not divisible any no. from 2 to n/2 then n is said to prime 
		  
}


main()
{
	int n;
	cout<<"Prime Checker\n\nEnter a no. to check if it is prime :" ;
	cin>>n;
	cout<<"\n";
	if(isprime(n,n/2) )
		cout<<"True";
	else cout<<"false";
	getch();
	
}


