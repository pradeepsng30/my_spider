#include<iostream>
#include<conio.h>

using namespace std;

int sum( int array[],int size)//without extending argument
{                      //initially size is equal to real size of array
	if (size>0)
		return array[size-1]+sum(array,size-1);
				//sum of last element and rest of the element is returned... size is reudced by 1 for each call
	else return 0;// call continues till size becomes zero and zero is returned	
}


int sum( int array[],int size,int index)
{                     //index moves from zero to size of array by incrementing at each recursive call
 if(index<size-1)
 	return array[index] + sum(array,size,index+1);
 
 else return array[index] ;
						  // when index reahes at last element .. call is terminated and last elemnt is returned
 
}


main()
{
int array[100],size;

cout<<"Sum of array elements\n\nEnter no. of elements  : ";
cin>>size;


cout<<"\nEnter elements";

for(int i=0;i<size;i++)
	cin>>array[i];
	
cout<<"\n\nsum of elementsis (without extending arguement) : "<<sum(array,size);

cout<<"\nsum of elementsis (by extending arguement) : "<<sum(array,size,0);

getch();
}


