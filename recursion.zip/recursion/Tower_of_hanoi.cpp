#include <iostream>
#include<conio.h>

using namespace std;

//3pegs are used numbered 1,2 &3 in output.... but numbered 0,1 & 2 inside code
//disksize is from 0 to no. of disk -1
//disksize is the no. of disks we have to operate on -1 .. it is also the size of disk we are operating upon
//if no. of disk is 4.. then min size of disk is 0... max is 3 
void hanoi(int diskSize, int source, int dest, int spare)
{
  //termination case... when we are operating upon smallest disk...ie disksize=0
  if(diskSize == 0)
	{
		cout << "Move disk_" << diskSize << " from " << source+1 << " to " << dest+1 << endl;
	}
	else
	{
		//Move all disks smaller than this one over to the spare.
    //So if diskSize is 5, we move 4 disks to the spare. This leaves us with 1 disk
    //on the source peg.
    
    //We are now using the dest peg as the spare peg. This causes each recursion to ping-pong
    //the spare and dest pegs.
		hanoi(diskSize - 1, source, spare, dest);

		//Move the remaining disk to the destination peg.
		cout << "Move disk_"  << diskSize << " from " << source+1 << " to " << dest+1 << endl;

		//Move the disks we just moved to the spare back over to the dest peg.
		hanoi(diskSize - 1, spare, dest, source);
	}
}

main()
{
  
	int no_of_disk;

	cout<<"Tower of Hanoi\n\nEnter no. of disk : ";

	cin>>no_of_disk;

  hanoi(no_of_disk-1, 0, 1, 2);//as size starts from zero

  getch();
}


